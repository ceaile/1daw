/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author cristina según el código del ejemplo 4.1 de la ud9_POO".pdf
 */
class Madre {

    void llamame() {
        System.out.println("Estoy en la clase Madre");
    }
}

class Hija1 extends Madre {

    void llamame() {
        System.out.println("Estoy en la clase Hija1");
    }
}

class Hija2 extends Madre {

    void llamame() {
        System.out.println("Estoy en la clase Hija2");
    }
}

public class Ejemplo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Madre madre = new Madre();
        Hija1 h1 = new Hija1();
        Hija2 h2 = new Hija2();

        //Declaramos otra variable de tipo Madre,
        //sin crear un objeto
        Madre madre2;

        //Asignamos a madre2 el objeto madre, de tipo Madre
        //y llamamos a su método llamame()
        madre2 = madre;
        madre2.llamame();

        /*Asignamos a madre2 el objeto h1, de tipo Hija1, 
        podemos hacerlo porque Hija1 es subclase de Madre y por lo tanto,
        también es de tipo Madre,
        y llamamos a su método llamame()*/
        madre2 = h1;
        madre2.llamame();

        /*Asignamos a madre2 el objeto h2, de tipo Hija2, 
        podemos hacerlo porque Hija2 es subclase de Madre y por lo tanto,
        también es de tipo Madre,
        y llamamos a su método llamame()*/
        madre2 = h2;
        madre2.llamame();
    }

}
